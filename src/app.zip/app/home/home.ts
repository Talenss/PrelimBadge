import { Component, AfterViewInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-home',
  imports: [],
  templateUrl: './home.html',
  styleUrls: ['./home.css'],
})
export class Home implements AfterViewInit {
  @ViewChild('heroVideo') heroVideo!: ElementRef<HTMLVideoElement>;
  // Hero text
  title = 'Research Conferences';
  description = 'Join our online events this 2026!';
  image = 'https://i0.wp.com/digital-photography-school.com/wp-content/uploads/2023/07/cityscape-photography-2.jpg?fit=1500%2C1000&ssl=1';
  // Stats section
  value = 'Join our Research Conferences around the globe';

  // Featured products
  products = [
    { id: 1, title: 'France', img: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQqfzVzLBgb90htNWmV1DQINGAU362kn3HzBQ&s", description: "The largest country in Western Europe, has long been a gateway between the continent's northern and southern regions", features: ['Architecture and Fine Arts', 'Cultural Events', 'Safety and Security']},
    { id: 2, title: 'Seoul', img: 'https://touristjourney.com/wp-content/uploads/2025/01/Golden-Sunset-Over-Seoul-Urban-Nightscape-Seoul-Korea-1024x683.jpg', description: "Korean Soul, formally Soul-t'ükpyõlsi ('Special City of Seoul'), city and capital of South Korea (the Republic of Korea).", features: ['Humanities and Arts', 'Cultural Events', 'Safety and Security']},
    { id: 3, title: 'San Francisco', img: 'https://images.contentstack.io/v3/assets/blt06f605a34f1194ff/bltc85bbcd6ff5fa0fd/650882a0a39cd61ce6ace86f/0_-_BCC-2023-THINGS-TO-DO-IN-SAN-FRANCISCO-AT-NIGHT-0.webp?fit=crop&disable=upscale&auto=webp&quality=60&crop=smart', description: "It is a cultural and financial centre of the western United States and one of the country's most cosmopolitan cities.",features: ['Science and Technology', 'Cultural Events', 'Safety and Security']},
    { id: 4, title: 'Boston', img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTRmsOdeXBpaHNwy0Jk7KlrNqiMefJwakI2LA&s', description: 'Best known for its famous baked beans, Fenway Park, The Boston Marathon, and of course for the bar from Cheers. Engineering and Tech Cultural Events', features: ['Engineering and Tech', 'Cultural Events', 'Safety and Security']}
  ];

  // href link
  linkseoul = 'https://en.wikipedia.org/wiki/Seoul';
  linkboston = 'https://en.wikipedia.org/wiki/Boston';
  linksanfrancisco = 'https://en.wikipedia.org/wiki/San_Francisco';
  linkfrance = 'https://en.wikipedia.org/wiki/France';

  ngAfterViewInit(): void {
    try {
      const v = this.heroVideo.nativeElement;
      v.muted = true;
      v.volume = 0;
      // attempt to play muted video to satisfy autoplay policy
      v.play().catch(() => {});
    } catch (e) {
      // ignore if element not found
    }
  }

}
